from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Report

import json

@csrf_exempt
def generate_report(request):
    if request.method == "POST":
        data = json.loads(request.body)
        report = Report.objects.create(
            title=data.get("title"),
            content=data.get("content"),
        )
        return JsonResponse({"message": "Report created!", "id": report.id}, status=201)

    return JsonResponse({"error": "Invalid request"}, status=400)
